The "SOAP UI Project" folder contains source code of A2A project to test AECB A2A services:
1. User have to download & install SOAPUI 5.3 or above from www.soapui.org on Windows 7 or 8 desktop that has internet connectivity.
2. Configure SOAP UI to use client certificate authentication following the document "A2A SOAP UI Client Certificate Authentication.docx" (the corresponding certificate must be whitelisted in the AECB systems first - please refer to "A2A Frequently Asked Questions.xlsx" for more information)
3. Import the file contained in the folder "SOAP UI Project"
4. Project will be created in SOAPUI with sample requests (to be further filled with data)
5. Modify the input values with actual data and press start button to process the request
6. Report will be available in response box

